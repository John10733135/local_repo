<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" act-item-content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            padding: 0;
            margin: 0;
        }

        .act-wrap {
            width: 80%;
            margin: auto;
        }

        #act-wrap ul li {
            display: inline;
        }

        .act-item {
            /* 設定活動外框 */
            border-radius: 5px;
            border: 3px solid cornflowerblue;
            /* 設定活動文字 */
            color: black;
            /* 設定 size */
            margin: auto;
            width: 30%;
            height: 100%;
            margin: 5% 1%;
            /* 排版 */
            float: left;

            transition: .5s;
            /* 漸變 */
        }

        .item-bg {
            /* 整個活動的背景色 */
            background-color: #F0F8FF;
        }

        .act-item h3 {
            /* 設定標題為 h3 */
            text-align: center;
            background-color: #00BFFF;
            color: white;
            font-weight: bold;
        }

        .act-item-photo {
            width: 100%;
            height: 200px;
        }

        .act-item-photo img {
            /* 設定圖片大小 */
            width: 100%;
            height: 100%;
        }

        .act-item-content {
            /* 設定內文文字 */
            text-align: center;
            padding: 0.5%;

            -webkit-line-clamp: 5;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            text-overflow: ellipsis;
            overflow: hidden;
        }

        .act-item-content:hover {
            /* 設定內文文字 */
            text-align: center;
            padding: 1%;

            -webkit-line-clamp: unset;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            text-overflow: ellipsis;
            overflow: hidden;
        }


        .act-item-price {
            text-align: center;
            text-overflow: ellipsis;
            overflow: hidden;
        }

        .act-item-price hr {
            background-color: black;
            width: 95%;
            margin: auto;
        }

        .itemBtn {
            width: 50%;
            height: 100%;
            text-align: center;
            background-color: #5E86C1;
            border-color: transparent;
            border-radius: 3px;
            color: white;
            font-weight: bold;
            padding: 2px;
        }

        .act-btn {
            text-align: center;
        }

        .itemBtn a {
            display: inline;
        }

        @media screen and (max-width: 768px) {
            * {
                padding: 0;
                margin: 0;
            }

            .act-wrap {
                width: 100%;
                margin: auto;
                /* padding-left: 3%; */
            }

            #act-wrap ul li {
                display: inline;
            }

            .act-item-sm {
                /* 設定活動外框 */
                border-radius: 5px;
                border: 3px solid cornflowerblue;
                /* 設定活動文字 */
                color: black;
                /* 設定 size */
                margin: 5% auto;
                margin-left: 10%;
                width: 80%;
                height: 100%;
                /* 排版 */
                float: left;

                transition: .5s;
                /* 漸變 */
            }

            .item-bg {
                /* 整個活動的背景色 */
                background-color: #F0F8FF;
            }

            .act-item h3 {
                /* 設定標題為 h3 */
                text-align: center;
                background-color: #00BFFF;
                color: white;
                font-weight: bold;
            }

            .act-item-photo img {
                /* 設定圖片大小 */
                width: 100%;
                height: 100%;
            }

            .act-item-content {
                /* 設定內文文字 */
                text-align: center;
                padding: 0.5%;

                -webkit-line-clamp: 5;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                text-overflow: ellipsis;
                overflow: hidden;
            }

            .act-item-content:hover {
                /* 設定內文文字 */
                text-align: center;
                padding: 1%;

                -webkit-line-clamp: unset;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                text-overflow: ellipsis;
                overflow: hidden;
            }


            .act-item-price {
                text-align: center;
                text-overflow: ellipsis;
                overflow: hidden;
            }

            .act-item-price hr {
                background-color: black;
                width: 95%;
                margin: auto;
            }

            .itemBtn {
                width: 50%;
                height: 100%;
                text-align: center;
                background-color: #5E86C1;
                border-color: transparent;
                border-radius: 3px;
                color: white;
                font-weight: bold;
                padding: 2px;
            }

            .act-btn {
                text-align: center;
            }

            .itemBtn a {
                display: inline;
            }
        }
    </style>
</head>

<body>
    <div class="act-wrap" id="act-wrap">
        <ul>
            <?php
            date_default_timezone_set('Asia/Taipei');
            $now = strtotime(date("Y-m-d"));
            for ($i = 0; $i < sizeof($this->items); $i++) {
                $tempAct = substr($this->items[$i]->act_advance, 0, 10);
                $actTime = strtotime("$tempAct");
                if ($now < $actTime) { ?>
                    <li>
                        <div class="act-item act-item-sm item-bg">
                            <div class="act-item-photo item-bg">
                                <img src="<?php echo $this->items[$i]->act_image; ?>">
                            </div>
                            <h3>
                                <?php echo $this->items[$i]->act_name; ?>
                            </h3>
                            <br>
                            <p class="act-item-content item-bg">
                                <?php echo strip_tags($this->items[$i]->act_intro); ?>
                            </p>
                            <br>
                            <div class="act-btn item-bg">
                                <a href="<?php echo JUri::getInstance() . '?view=actdata&actID=' . $this->items[$i]->act_id; ?>"><button class="itemBtn">see details</button></a>
                            </div>
                            <br>
                            <hr><br>
                            <p class="act-item-price item-bg">$ <?php echo $this->items[$i]->act_price; ?> / 人</p>
                            <br>
                        </div>
                    </li>
            <?php }
            } ?>
        </ul>
    </div>
</body>

</html>