<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$input = JFactory::getApplication()->input;
$actID = $input->get('actID');

if (isset($actID)) {
    $aHuman = [];
    $ckOrder = [];
    $orderNum = 0;
    foreach ($this->items as $value) {

        if (isset($value->order_id) && $value->order_status != -1) {
            if (!in_array($value->order_id, $ckOrder)) {
                $ckOrder[] = $value->order_id;
                $orderNum += $value->order_adult + $value->order_child;
            }
        }
        if (isset($value->act_human_rule) && $value->act_human_rule == 0) {
            $aEarly = $value->act_early_rule;
            $aEarlyP = $value->act_discount;
        } elseif (isset($value->act_human_rule) && $value->act_human_rule != null) {
            if (!in_array($value->act_human_rule, $aHuman)) {
                $aHuman[] = $value->act_human_rule;
                $aHumanP[] = $value->act_discount;
            }
        }
    }
}

$ruleCounter = 0;
if (!empty($aEarly)) {
    $ruleCounter++;
}
if (sizeof($aHuman) != 0) {
    $ruleCounter += sizeof($aHuman);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $this->items[0]->act_name; ?></title>
    <style>
        * {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .banner h1 {
            font-size: 46px;
            text-align: center;
        }

        .banner img {
            width: 100%;
        }

        img {
            vertical-align: bottom;
            margin-bottom: 10px;
        }

        .wrap {
            width: 100%;
            margin: auto;
            text-align: center;
        }

        .wrap p {
            text-align: center;
            margin: auto;
            width: 100%;
        }

        .wrap .actData,
        .wrap .peopleData {
            width: 100%;
            transition: .3s;
        }

        .item {
            margin: 0 10px 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        .item h3 {
            font-size: 24px;
        }

        .wrap a {
            display: block;
            box-sizing: border-box;
            text-decoration: none;
            border: 1px solid #aaa;
            color: black;
            font-weight: bold;
            border-radius: 5px;
            margin: 10px auto;
            padding: 5px;
            transition: .3s;
        }

        @media screen and (min-width:768px) {
            .wrap {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-around;
            }

            .wrap .actData,
            .wrap .peopleData {
                width: 50%;
            }

            .item {
                box-sizing: border-box;
            }
        }
    </style>

</head>

<body>
    <div class="banner">
        <h1><?php echo $this->items[0]->act_name; ?></h1>
        <img src="<?php echo $this->items[0]->act_image; ?>">
    </div>
    <div class="wrap">
        <div class="actData">
            <div class="item">
                <h3>活動簡介</h3>
                <p><?php echo $this->items[0]->act_intro; ?></p>
            </div>
            <div class="item">
                <h3>活動內容</h3>
                <p><?php echo $this->items[0]->act_content; ?></p>
            </div>
            <div class="item">
                <h3>活動日期</h3>
                <p><?php echo substr($this->items[0]->act_time_start, 0, 10); ?></p>
            </div>
            <div class="item">
                <h3>活動時間</h3>
                <p><?php echo substr($this->items[0]->act_time_start, -8) . " ~ " . substr($this->items[0]->act_time_end, -8) . " ( 約 " . (strtotime($this->items[0]->act_time_end) - strtotime($this->items[0]->act_time_start)) / (60) . " 分 )"; ?></p>
            </div>
            <div class="item">
                <h3>活動地點</h3>
                <p><?php echo $this->items[0]->act_loc; ?></p>
            </div>
        </div>
        <div class="peopleData">
            <div class="item">
                <h3>人數下限</h3>
                <p><?php echo $this->items[0]->act_lower; ?></p>
            </div>
            <div class="item">
                <h3>人數上限</h3>
                <p><?php echo $this->items[0]->act_upper; ?></p>
            </div>
            <div class="item">
                <h3>當前人數</h3>
                <p><?php echo $orderNum; ?></p>
            </div>
            <div class="item">
                <h3>早鳥優惠</h3>
                <?php
                if (isset($aEarly)) {
                    echo "<p>" . substr($aEarly, 0, 10) . " 前報名即享優惠價 $aEarlyP  元</p>";
                } else {
                    echo "<p>此活動無早鳥優惠</p>";
                }
                ?>
            </div>
            <div class="item">
                <h3>團報優惠</h3>
                <?php
                if (isset($aHuman) && sizeof($aHuman) != 0) {
                    for ($i = 0; $i < sizeof($aHuman); $i++) {
                        echo "<p>優惠" . ($i + 1) . " : " . $aHuman[$i] . " 人同行報名享優惠價 " . $aHumanP[$i] . " 元</p><br>";
                    }
                } else {
                    echo "<p>此活動無團報優惠</p><br>";
                }
                ?>
            </div>
        </div>
        <?php
        if ($orderNum > $this->items[0]->act_upper) { ?>
            <p>該活動已達最高人數限制</p>
            <a href="<?php echo JUri::base() . "index.php/join"; ?>">回活動列表</a>
        <?php } else { ?>
            <a href="<?php echo str_replace('data', 'form', JUri::getInstance()); ?>">我要報名</a>
        <?php } ?>
    </div>
</body>

</html>