<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
$input = JFactory::getApplication()->input;
$actID = $input->get('actID');

if (isset($actID)) {
    $aEarly = 0;
    $aEarlyP = 0;

    foreach ($this->items as $value) {
        if (isset($value->act_human_rule) && $value->act_human_rule == '0') {
            $aEarly = $value->act_early_rule;
            $aEarlyP = $value->act_discount;
        } elseif (isset($value->act_human_rule) && $value->act_human_rule != null) {
            $aHuman[] = $value->act_human_rule;
            $aHumanP[] = $value->act_discount;
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mbr</title>
    <style>
        * {
            margin: 0;
            padding: 0;
        }

        .container {
            margin: 1% auto;
            padding: 1%;
            width: 60%;
            border: 3px solid black;
            background-color: white;
            box-sizing: border-box;
            border-radius: 3px;
        }

        h3 {
            text-align: center;
        }

        .formLabel {
            width: 35%;
            padding: 1%;
            text-align: right;
            float: left;
            box-sizing: border-box;
        }

        .formInput {
            width: 50%;
            padding: 1%;
            margin: auto;
            float: left;
            box-sizing: border-box;
        }

        label {
            font-size: 100%;
            margin-right: 10%;
            font-weight: bold;
        }

        input {
            padding: 1%;
            display: block;
            background-color: #E0FFFF;
            width: 80%;
        }

        #mbrBankCode {
            padding: 1%;
        }

        .setMid {
            margin: auto;
        }

        .btn {
            background-color: #5E86C1;
            color: white;
            font-weight: bold;
            width: 100%;
            margin: 1% auto;
            clear: both;
        }

        .clearfix {
            clear: both;
        }
    </style>
</head>

<body>
    <script>
        function countAmount() {
            actPrice = "<?php echo $this->items[0]->act_price; ?>";
            aEarly = "<?php echo $aEarly; ?>";
            aEarlyP = "<?php echo $aEarlyP; ?>";
            aHuman = [<?php echo json_encode($aHuman); ?>];
            aHumanP = [<?php echo json_encode($aHumanP); ?>];
            amount = document.getElementById('mbrAmount');
            adult = document.getElementById('mbrAdult');
            showMsg = document.getElementById('showMsg');
            countEarly = 0;
            countDiscount = 0;
            nowDay = new Date();

            curHuman = 0;
            curHumanP = 0;

            if (parseInt(adult.value) > 0) {

                if (parseInt(aEarlyP) != 0) {
                    var actDay = new Date(aEarly.replace('-', ','));
                    if (nowDay.toDateString() <= actDay.toDateString()) {
                        countEarly = parseInt(adult.value) * parseInt(aEarlyP);
                    }
                }


                for (let i = 0; i < aHuman[0].length; i++) {
                    if (parseInt(adult.value) >= parseInt(aHuman[0][i])) {
                        console.log(parseInt(aHuman[0][i]))
                        curHuman = parseInt(aHuman[0][i]);
                        curHumanP = parseInt(aHumanP[0][i]);
                        countDiscount = parseInt(adult.value) * parseInt(aHumanP[0][i]);
                    }
                }
            }

            if (countEarly != 0 && countDiscount != 0) {
                amount.value = Math.min(countEarly, countDiscount);
                if (countEarly < countDiscount)
                    showMsg.innerHTML = "<font color='blue'>符合早鳥折扣 以早鳥價" + aEarlyP + "計算</font>";
                else
                    showMsg.innerHTML = "<font color='blue'>符合人數折扣 以" + curHuman + "人(含以上) " + curHumanP + "/人 計算</font>";
            } else if (countDiscount != 0) {
                amount.value = countDiscount;
                showMsg.innerHTML = "<font color='blue'>符合人數折扣" + curHuman + "人(含以上) 以" + curHumanP + "/人 計算</font>";
            } else {
                amount.value = parseInt(adult.value) * parseInt(actPrice);
                showMsg.innerHTML = "<font color='blue'>不符合任何折扣 以原價" + actPrice + "計算</font>";
            }
        }
    </script>

    <div class="container">
        <form action="<?php echo JUri::getInstance() . '&task=actform.save'; ?>" id="actForm" name="actForm" method="post">
            <input type="hidden" name="actID" id="actID" value="<?php echo $actID; ?>">
            <h3><?php echo $this->items[0]->act_name; ?>活動報名表單</h3>
            <br>
            <div class="formLabel">
                <label for="mbrName">
                    <font color="red">*</font>姓名 :
                </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrName" id="mbrName" required>
            </div>

            <div class="formLabel">
                <label for="mbrPhone">
                    <font color="red">*</font>行動電話 :
                </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrPhone" id="mbrPhone" pattern="09\d{2}(\d{6}|-\d{3}-\d{3})" placeholder="0912345678" required>
            </div>

            <div class="formLabel">
                <label for="mbrTel">
                    <font color="red">*</font>室內電話 :
                </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrTel" id="mbrTel" placeholder="01-1234567" required>
            </div>

            <div class="formLabel">
                <label for="mbrMail">
                    <font color="red">*</font>電子信箱 :
                </label>
            </div>
            <div class="formInput">
                <input type="email" name="mbrMail" id="mbrMail" required>
            </div>

            <div class="formLabel">
                <label for="mbrMemo">Line 帳號 / FB 名稱 : </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrMemo" id="mbrMemo">
            </div>

            <div class="formLabel">
                <label for="mbrAdult">
                    <font color="red">*</font>成人參加人數 :
                </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrAdult" id="mbrAdult" onchange="javascript:countAmount()" maxlength="2" required>
            </div>

            <div class="formLabel">
                <label for="mbrChild">
                    <font color="red">*</font>孩童參加人數 :
                </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrChild" id="mbrChild" maxlength="2" required>
            </div>

            <div class="formLabel">
                <label for="mbrAmount">
                    訂單金額 :
                </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrAmount" id="mbrAmount" value="0" readonly required>
            </div>
            <div class="formLabel">
            </div>
            <div class="formInput" id="showMsg"></div>
            <div class="formLabel">
                <label for="mbrBank">
                    <font color="red">*</font>銀行帳號 (後五碼) :
                </label>
            </div>
            <div class="formInput">
                <input type="text" name="mbrBank" id="mbrBank" maxlength="5" required>
                <br>
            </div>

            <div class="setMid">
                <input type="submit" class="btn" value="送出">
            </div>

            <div class="clearfix"></div>
    </div>
    </form>
    </div>
</body>

</html>