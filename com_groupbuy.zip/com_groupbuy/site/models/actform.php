<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
class GroupBuyModelActform extends JModelList
{
	protected function getListQuery()
	{
		// Initialize variables.
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);
		$input = JFactory::getApplication()->input;
		$id = $input->get('actID');
		$query->select(array('a.*'))
			->from($db->quoteName('checkActData', 'a'))
			->where($db->quoteName('act_id') . '=' . $db->quote($id));

		$this->setState('list.limit', 0);

		return $query;
	}

	public function save($data)
	{
		$db = JFactory::getDbo();

		$formQuery = $db->getQuery(true);

		// Insert columns.
		$formColumns = array('act_id', 'order_name', 'order_phone', 'order_tel', 'order_mail', 'order_memo', 'order_adult', 'order_child', 'order_amount', 'order_time', 'order_account', 'order_status');

		// Insert values.
		$formValues = array(
			$db->quote($data['actID']), $db->quote($data['mbrName']), $db->quote($data['mbrPhone']), $db->quote($data['mbrTel']), $db->quote($data['mbrMail']), $db->quote($data['mbrMemo']), $db->quote($data['mbrAdult']), $db->quote($data['mbrChild']), $db->quote($data['mbrAmount']), $db->quote($data['mbrTime']), $db->quote($data['mbrBank']), 0
		);

		// Prepare the insert query.
		$formQuery
			->insert($db->quoteName('#__groupbuy_order'))
			->columns($db->quoteName($formColumns))
			->values(implode(',', $formValues));
		$db->setQuery($formQuery);
		$db->execute();
	}
}
