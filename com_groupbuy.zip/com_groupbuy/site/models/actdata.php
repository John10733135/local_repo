<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
class GroupBuyModelActdata extends JModelList
{
	protected function getListQuery()
	{
		// Initialize variables.
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query2 = $db->getQuery(true);

		$input = JFactory::getApplication()->input;

		$id = $input->get('actID');
		$this->setState('list.limit', 0);

		// if (!$id) {
		// 	header(JUri::getInstance().'&task=actform');
		// }

		// Create the base select statement.

		$query->select(array('o.order_id', 'o.order_adult', 'o.order_child', 'o.order_status', 'a.*'))
			->from($db->quoteName('#__groupbuy_order', 'o'))
			->join('INNER', $db->quoteName('checkActData', 'a') . ' ON ' . $db->quoteName('a.act_id') . ' = ' . $db->quoteName('o.act_id'))
			->where($db->quoteName('o.act_id') . '=' . $db->quote($id));

		$db->setQuery($query);
		$count = $db->loadResult();
		if (empty($count)) {
			$query2->select(array('a.*'))
				->from($db->quoteName('checkActData', 'a'))
				->where($db->quoteName('act_id') . '=' . $db->quote($id));
			return $query2;
		} else {
			return $query;
		}
	}
}
