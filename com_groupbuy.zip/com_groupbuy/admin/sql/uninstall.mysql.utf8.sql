DROP  TABLE  IF  EXISTS  `#__groupbuy_act`;
DROP  TABLE  IF  EXISTS  `#__groupbuy_act_rule`;
DROP  TABLE  IF  EXISTS  `#__groupbuy_farm`;
DROP  TABLE  IF  EXISTS  `#__farm_bank`;
DROP  TABLE  IF  EXISTS  `#__groupbuy_order`;

DROP  TRIGGER  IF  EXISTS  `tri_farmOnly1`;
DROP  TRIGGER  IF  EXISTS  `tri_farmOnly2`;
DROP  TRIGGER  IF  EXISTS  `tri_updateActID`;
DROP  TRIGGER  IF  EXISTS  `tri_updateRuleID`;
DROP  VIEW  IF  EXISTS  `mainData`;
DROP  VIEW  IF  EXISTS  `checkData`;
DROP  VIEW  IF  EXISTS  `checkActData`;
DROP  VIEW  IF  EXISTS  `checkActPublishData`;
