DROP  TABLE  IF  EXISTS  `#__groupbuy_act`;
DROP  TABLE  IF  EXISTS  `#__groupbuy_act_rule`;
DROP  TABLE  IF  EXISTS  `#__groupbuy_farm`;
DROP  TABLE  IF  EXISTS  `#__farm_bank`;
DROP  TABLE  IF  EXISTS  `#__groupbuy_order`;

DROP  TRIGGER  IF  EXISTS  `tri_farmOnly1`;
DROP  TRIGGER  IF  EXISTS  `tri_farmOnly2`;
DROP  TRIGGER  IF  EXISTS  `tri_updateActID`;
DROP  TRIGGER  IF  EXISTS  `tri_updateRuleID`;
DROP  VIEW  IF  EXISTS  `mainData`;
DROP  VIEW  IF  EXISTS  `checkData`;
DROP  VIEW  IF  EXISTS  `checkActData`;
DROP  VIEW  IF  EXISTS  `checkActPublishData`;

CREATE TABLE `#__groupbuy_act` (
  `act_id` int(3) NOT NULL PRIMARY KEY COMMENT '活動編號',
  `act_name` varchar(20) NOT NULL COMMENT '活動名稱',
  `act_intro` varchar(500) NOT NULL COMMENT '活動簡介',
  `act_content` varchar(1000) NOT NULL COMMENT '活動內容',
  `act_time_start` datetime NOT NULL COMMENT '活動開始時間',
  `act_time_end` datetime NOT NULL COMMENT '活動結束時間',
  `act_loc` varchar(25) NOT NULL COMMENT '活動地點',
  `act_upper` int(3) NOT NULL COMMENT '人數上限',
  `act_lower` int(3) NOT NULL COMMENT '人數下限',
  `act_price` decimal(4,0) NOT NULL COMMENT '活動價格',
  `act_status` int(1) NOT NULL COMMENT '發布狀態',
  `act_advance` datetime NOT NULL COMMENT '預先日期',
  `act_image` VARCHAR(1024) NOT NULL COMMENT '活動圖片',
  `farm_id` int(3) NOT NULL COMMENT '農場編號'
) 
  ENGINE = InnoDB
	DEFAULT CHARSET = utf8mb4
	DEFAULT COLLATE = utf8mb4_unicode_ci;

CREATE TABLE `#__groupbuy_act_rule` (
  `act_id` int(3) NOT NULL COMMENT '活動編號',
  `act_human_rule` varchar(20) NOT NULL COMMENT '人數優惠',
  `act_sale_type` int(1) NOT NULL COMMENT '優惠模式',
  `act_early_rule` datetime NOT NULL COMMENT '早鳥優惠',
  `act_discount` decimal(4,0) NOT NULL COMMENT '優惠價格',
   primary key (`act_id`,`act_human_rule`)
) 
  ENGINE = InnoDB
	DEFAULT CHARSET = utf8mb4
	DEFAULT COLLATE = utf8mb4_unicode_ci;

CREATE TABLE `#__groupbuy_farm` (
  `farm_id` int(3) NOT NULL PRIMARY KEY  COMMENT '農場編號',
  `farm_name` varchar(15) NOT NULL COMMENT '農場名稱',
  `farm_owner` varchar(10) NOT NULL COMMENT '農場負責人',
  `farm_loc` varchar(25) NOT NULL COMMENT '農場地點',
  `farm_tel` varchar(10) NOT NULL COMMENT '行動電話',
  `farm_phone` varchar(10) NOT NULL COMMENT '室內電話',
  `farm_bank_code` varchar(3) NOT NULL COMMENT '銀行代碼',
  `farm_account` varchar(16) NOT NULL COMMENT '銀行帳號'
) 
  ENGINE = InnoDB
	DEFAULT CHARSET = utf8mb4
	DEFAULT COLLATE = utf8mb4_unicode_ci;

INSERT INTO `#__groupbuy_farm`(`farm_id`)
VALUES(1);

CREATE TABLE `#__groupbuy_order` (
  `order_id` int(4) NOT NULL PRIMARY KEY AUTO_INCREMENT  COMMENT '訂單編號',
  `act_id` int(3) NOT NULL COMMENT '活動編號',
  `order_name` varchar(10) NOT NULL COMMENT '姓名',
  `order_tel` varchar(10) NOT NULL COMMENT '行動電話',
  `order_phone` varchar(10) NOT NULL COMMENT '室內電話',
  `order_mail` varchar(20) NOT NULL COMMENT '電子信箱',
  `order_memo` varchar(20) NOT NULL COMMENT '其餘聯繫方式',
  `order_adult` int(2) NOT NULL COMMENT '成人人數',
  `order_child` int(2) NOT NULL COMMENT '孩童人數',
  `order_account` varchar(5) NOT NULL COMMENT '銀行帳號',
  `order_time` datetime NOT NULL COMMENT '訂單成立時間',
  `order_amount` decimal(4,0) NOT NULL COMMENT '訂單金額',
  `order_status` int(1) NOT NULL COMMENT '訂單狀態'
) 
  ENGINE = InnoDB
	DEFAULT CHARSET = utf8mb4
	DEFAULT COLLATE = utf8mb4_unicode_ci;

CREATE TABLE `#__farm_bank` (
  `bank_code` varchar(3) NOT NULL COMMENT '銀行代碼',
  `bank_name` varchar(30) NOT NULL COMMENT '銀行名稱'
)
  ENGINE = InnoDB
	DEFAULT CHARSET = utf8mb4
	DEFAULT COLLATE = utf8mb4_unicode_ci;

INSERT INTO `#__farm_bank` (`bank_code`, `bank_name`) VALUES
('004', '台灣銀行'),
('005', '土地銀行'),
('006', '合作金庫'),
('007', '第一銀行'),
('008', '華南銀行'),
('009', '彰化銀行'),
('011', '上海銀行'),
('012', '富邦銀行'),
('013', '國泰世華'),
('016', '高雄銀行'),
('017', '兆豐商銀'),
('021', '花旗銀行'),
('039', '澳盛銀行'),
('048', '王道銀行'),
('050', '台灣企銀'),
('052', '渣打銀行'),
('053', '台中銀行'),
('081', '滙豐銀行'),
('101', '瑞興銀行'),
('102', '華泰銀行'),
('103', '新光銀行'),
('108', '陽信銀行'),
('147', '三信銀行'),
('700', '中華郵政'),
('803', '聯邦銀行'),
('805', '遠東銀行'),
('806', '元大銀行'),
('807', '永豐銀行'),
('808', '玉山銀行'),
('809', '凱基銀行'),
('810', '星展銀行'),
('812', '台新銀行'),
('815', '日盛銀行'),
('816', '安泰銀行'),
('822', '中國信託');

CREATE TRIGGER `tri_farmOnly1`
BEFORE INSERT
ON `#__groupbuy_farm` FOR EACH ROW
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'farm data only';

CREATE TRIGGER `tri_farmOnly2`
BEFORE DELETE
ON `#__groupbuy_farm` FOR EACH ROW
SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'farm data only';

CREATE VIEW `mainData`
AS
SELECT `#__groupbuy_act`.act_id,`#__groupbuy_act`.act_name,`#__groupbuy_act`.act_time_start,`#__groupbuy_act`.act_status,`#__groupbuy_farm`.farm_name
FROM `#__groupbuy_farm` LEFT OUTER JOIN `#__groupbuy_act`
ON `#__groupbuy_farm`.farm_id = `#__groupbuy_act`.farm_id;

CREATE VIEW `checkData`
AS
SELECT *
FROM `#__groupbuy_farm`,`#__farm_bank`
WHERE `#__groupbuy_farm`.farm_bank_code = `#__farm_bank`.bank_code;

CREATE TRIGGER `tri_updateActID`
AFTER UPDATE
ON `#__groupbuy_farm` FOR EACH ROW
UPDATE `#__groupbuy_act`
SET `#__groupbuy_act`.act_id = CONCAT((SELECT `#__groupbuy_farm`.farm_name FROM `#__groupbuy_farm`),RIGHT(`#__groupbuy_act`.act_id,4));

CREATE TRIGGER `tri_updateRuleID`
AFTER UPDATE
ON `#__groupbuy_farm` FOR EACH ROW
UPDATE `#__groupbuy_act_rule`
SET `#__groupbuy_act_rule`.act_id = CONCAT((SELECT `#__groupbuy_farm`.farm_name FROM `#__groupbuy_farm`),RIGHT(`#__groupbuy_act_rule`.act_id,4));

CREATE VIEW `checkActData`
AS
SELECT `#__groupbuy_act`.*,`#__groupbuy_act_rule`.act_human_rule,`#__groupbuy_act_rule`.act_early_rule,`#__groupbuy_act_rule`.act_discount
FROM `#__groupbuy_act` LEFT OUTER JOIN `#__groupbuy_act_rule`
ON `#__groupbuy_act`.act_id = `#__groupbuy_act_rule`.act_id;

CREATE VIEW `checkActPublishData`
AS
SELECT `#__groupbuy_act`.act_id,`#__groupbuy_act`.act_name,`#__groupbuy_act`.act_intro,`#__groupbuy_act`.act_advance,`#__groupbuy_act`.act_loc,`#__groupbuy_act`.act_price,`#__groupbuy_act`.act_image
FROM `#__groupbuy_act`
WHERE `#__groupbuy_act`.act_status = 1;