<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// Stop direct access of file 阻止直接存取文件
defined('_JEXEC') or die('Restricted access');
$session = JFactory::getSession();
$input = JFactory::getApplication()->input;
$actID = $input->get('actID');
$setDay = $input->get('setDay');
$earlyDay = date('Y-m-d', strtotime($setDay . "-1 day"));
$fName = '';
$fOwner = '';
$fLoc = '';
$fCode = '';
$fAcc = '';
$fTel = '';
$fPhone = '';

$aName = '';
$aIntro = '';
$aContent = '';
$aImage = '';
$atimeStart = '';
$atimeEnd = '';
$aLoc = '';
$aUpper = '';
$aLower = '';
$aPrice = '';
$aEarly = '';
$aEarlyP = '';
$aStatus = '';
$aAdvance = '';
$aHuman = [];
$aHumanP = [];
$ruleLen = 0;

if (isset($actID)) {
    foreach ($this->items as $value) {
        if (isset($value->act_name) && $value->act_name != '')
            $aName = $value->act_name;
        if (isset($value->act_intro) && $value->act_intro != '')
            $aIntro = $value->act_intro;
        if (isset($value->act_content) && $value->act_content != '')
            $aContent = $value->act_content;
        if (isset($value->act_image) && $value->act_image != '')
            $aImage = "<p><img src='$value->act_image' alt='' /></p>";
        if (isset($value->act_time_start) && $value->act_time_start != '')
            $atimeStart = substr($value->act_time_start, -8);
        if (isset($value->act_time_end) && $value->act_time_end != '')
            $atimeEnd = substr($value->act_time_end, -8);
        if (isset($value->act_loc) && $value->act_loc != '')
            $aLoc = $value->act_loc;
        if (isset($value->act_upper) && $value->act_upper != '')
            $aUpper = $value->act_upper;
        if (isset($value->act_lower) && $value->act_lower != '')
            $aLower = $value->act_lower;
        if (isset($value->act_price) && $value->act_price != '')
            $aPrice = $value->act_price;
        if (isset($value->act_status) && $value->act_status != '')
            $aStatus = $value->act_status;
        if (isset($value->act_advance) && $value->act_advance != '')
            $aAdvance = substr($value->act_advance, 0, 10);
        if (isset($value->act_human_rule) && $value->act_human_rule == '0') {
            $aEarly = $value->act_early_rule;
            $aEarlyP = $value->act_discount;
        } else if (isset($value->act_human_rule) && $value->act_human_rule != null) {
            $aHuman[] = $value->act_human_rule;
            $aHumanP[] = $value->act_discount;
        }
    }
    $ruleLen = sizeof($aHuman);
} else {
    foreach ($this->items as $value) {
        if (isset($value->farm_name) && $value->farm_name != '')
            $fName = $value->farm_name;
        if (isset($value->farm_owner) && $value->farm_owner != '')
            $fOwner = $value->farm_owner;
        if (isset($value->farm_loc) && $value->farm_loc != '')
            $fLoc = $value->farm_loc;
        if (isset($value->bank_code) && $value->bank_code != '')
            $fCode = $value->bank_code;
        if (isset($value->farm_account) && $value->farm_account != '')
            $fAcc = $value->farm_account;
        if (isset($value->farm_tel) && $value->farm_tel != '')
            $fTel = $value->farm_tel;
        if (isset($value->farm_phone) && $value->farm_phone != '')
            $fPhone = $value->farm_phone;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add act layout use dom</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: "Microsoft JhengHei";
        }

        .wrap {
            margin: auto auto 1% auto;
            width: 80%;
            text-align: center;
            border: 3px #1E90FF dashed;
            padding: 1%;
        }

        .farm hr {
            width: 85%;
            margin: auto;
        }

        .actTitle {
            width: 82.5%;
            padding: 1% 0 1% 0;
            text-align: center;
            margin: 1% auto 1% auto;
            font-weight: bold;
            background-color: #1E90FF;
            color: white;
            border-radius: 5px;
        }

        h2 {
            text-align: left;
            margin-left: 8%;
        }

        .actData {
            width: 85%;
            margin: auto;
            padding: 2%;
            margin-left: 8%;
        }

        .actData input {
            width: 80%;
            padding: 1%;
            text-align: center;
        }

        p {
            text-align: left;
            font-weight: bold;
            margin-left: 14%;
            margin-top: 1%;
        }

        .people p {
            text-align: left;
            font-weight: bold;
            margin: auto;
        }

        .actEarly {
            text-align: left;
            margin-left: 20%;
        }

        .allBtn {
            background-color: #5E86C1;
            border-color: white;
            border-style: double;
            border-radius: 25px;
            color: white;
            font-size: 120%;
            font-weight: bold;
            width: 10%;
            padding: 0.1%;
            display: inline-block;
        }

        #submit {
            background-color: #2ac093;
            border-color: white;
            border-style: double;
            border-radius: 25px;
            color: white;
            font-size: 120%;
            font-weight: bold;
            width: 10%;
            padding: 0.1%;
        }

        #delBtn {
            background-color: #DC143C;
            border-color: white;
            border-style: double;
            border-radius: 25px;
            color: white;
            font-size: 120%;
            font-weight: bold;
            width: 10%;
            padding: 0.1%;
        }

        .orderPage {
            text-align: center;
            text-decoration: none;
            background-color: teal;
            color: white;
            font-size: 18px;
            border-radius: 5px;
            padding: 10px;
            margin: auto;
        }

        .c {
            text-align: center;
        }
    </style>
</head>

<body>
    <?php if (!isset($actID)) { ?>
        <div class="actTitle">
            <h1>Farm Information</h1>
        </div>

        <div class="wrap farm" name="wrap farm" id="wrap farm">
            <br>
            <h2>Name</h2>
            <h3><?php echo $fName; ?></h3>
            <hr><br>
            <h2>Address</h2>
            <h3 id='farmLoc'><?php echo $fLoc; ?></h3>
            <hr><br>
            <h2>Phone / Tel</h2>
            <h3><?php echo $fTel . '、' . $fPhone; ?></h3>
            <hr><br>
            <h2>Bank code</h2>
            <h3><?php echo $fCode . " - " . $fAcc; ?></h3>
            <hr><br>
            <h2>Owner</h2>
            <h3><?php echo $fOwner; ?></h3>
            <hr><br>
            <a href="index.php?option=com_groupbuy&view=addfarm" target="window_view">
                <button class="allBtn">Edit</button></a>
            <br>
        </div>
    <?php }; ?>
    <?php
    if (isset($actID)) {
        echo "<div class='c'>";
        echo '<a class="orderPage" href="index.php?option=com_groupbuy&view=editorder&actID=' . $actID . '" target="window_view">前往訂單管理頁面</a>';
        echo "</div>";
    }

    ?>
    <div class="actTitle">
        <h1>Activity Information</h1>
    </div>

    <div class="wrap act" name="wrap act" id="wrap act">
        <?php if (isset($actID)) { ?>
            <form name="actForm" id="actForm" method="post" action="<?php echo JUri::getInstance() . '&task=addact.edit'; ?>">
            <?php } else { ?>
                <form name="actForm" id="actForm" method="post" action="<?php echo JUri::getInstance() . '&task=addact.save'; ?>">
                <?php } ?>
                <input type="hidden" name="saveDate" id="saveDate" value="<?php if (isset($setDay)) {
                                                                                echo $setDay;
                                                                            } ?>">
                <input type="hidden" name="saveFarmID" id="saveFarmID" value="1">
                <input type="hidden" name="saveNextActID" id="saveNextActID" value="<?php if (!empty($session->get('lastActName'))) {
                                                                                        echo $session->get('lastActName');
                                                                                    } ?>">
                <br><br>
                <h2>Name</h2>
                <div class="actData" name="actData" id="actData">
                    <input type="input" name="actName" id="actName" value="<?php echo $aName; ?>" required>
                </div>
                <br><br>
                <h2>Intro</h2>
                <div class="actData" name="actData" id="actData">
                    <?php echo $this->introEditor->display('actIntro', $aIntro, '80%', '100%', 100, 50); ?>
                </div>
                <br><br>
                <h2>Content</h2>
                <div class="actData" name="actData" id="actData">
                    <?php echo $this->contentEditor->display('actContent', $aContent, '80%', '100%', 100, 50); ?>
                </div>
                <br><br>

                <h2>Photo</h2>
                <div class="actData" name="actData" id="actData">
                    <?php echo $this->imageEditor->display('actImage', $aImage, '80%', '100%', 100, 50); ?>
                </div>
                <br><br>

                <h2>Time</h2>
                <br><br>
                <p>Start</p>
                <div class="actData" name="actData" id="actData">
                    <input type="time" name="actTimeBegin" id="actTimeBegin" value="<?php echo $atimeStart; ?>" required onblur="javascript:ControlTime()">
                </div>
                <p>End</p>
                <div class="actData" name="actData" id="actData">
                    <input type="time" name="actTimeEnd" id="actTimeEnd" value="<?php echo $atimeEnd; ?>" required onblur="javascript:ControlTime()">
                </div>
                <h2>Address</h2>
                <div class="actData" name="actData" id="actData">
                    <input type="input" name="actLoc" id="actLoc" value="<?php echo $aLoc; ?>" required>
                </div>
                <br><br>
                <h2>Price</h2>
                <div class="actData" name="actData" id="actData">
                    <input type="input" name="actPrice" id="actPrice" value="<?php echo $aPrice; ?>" required>
                </div>
                <br><br>
                <h2>People Upper Bound</h2>
                <div class="actData" name="actData" id="actData">
                    <input type="number" name="actUpper" id="actUpper" required onblur="javascript:getPeople()" value="<?php echo $aUpper; ?>">
                    <div class="upperPeople" name="upperPeople" id="upperPeople">
                    </div>
                </div>
                <h2>Rules</h2><br>
                <p>Early bird discount - Sign up before the event can be discounted</p><br>
                <div class="actEarly" name="actEarly" id="actEarly">
                    <input type="checkbox" name="actEarlyInput" id="actEarlyInput" onchange="javascript:checkEarlyBird()" value="1" <?php if ($aEarly != '') {
                                                                                                                                        echo 'checked';
                                                                                                                                    } ?>>
                    <span> Do you have early bird discount discount ?</span>
                </div>
                <br>
                <p>Group discount - exceeding people can discount</p>
                <br>
                <div class="addPeopleRule">
                    <br>
                    <div class="peopleRule" name="peopleRule" id="peopleRule"></div>
                    <br>
                    <div class="allBtn" onclick="javascript:addRule()">+</div>
                    &nbsp;&nbsp;&nbsp;
                    <div class="allBtn" onclick="javascript:reduceRule()">-</div>
                    <br><br>
                </div>
                <input type="checkbox" name="publishStatus" id="publishStatus" value="1" <?php if (!isset($actID) || $aStatus == 1) {
                                                                                                echo "checked";
                                                                                            } ?> onclick="javascript:checkJoinDay()">&nbsp;<span>Whether to post an event ?</span>
                &nbsp;&nbsp;
                <span>Activity advance day : </span>
                <input type="date" name="actAdvance" id="actAdvance" value="<?php if (isset($actID) && $aStatus == 1) {
                                                                                echo $aAdvance;
                                                                            } ?>" required max="<?php if (isset($setDay)) {
                                                                                                    echo $earlyDay;
                                                                                                } ?>">
                <br><br>
                <hr><br><br>
                <input type="submit" name="submit" id="submit" value="<?php if (isset($actID)) {
                                                                            echo 'edit';
                                                                        } else {
                                                                            echo 'create';
                                                                        } ?>">
                </form>
                <?php
                if (isset($actID)) {
                    echo '<a href="' . JUri::getInstance() . '&ruleCount=' . $ruleLen . '&task=addact.deleteAct' . '"><button id="delBtn">del</button></a>';
                }
                ?>
                <br><br>
    </div>


    <script>
        /* get addDay */
        ruleCount = 0
        <?php for ($i = 0; $i < $ruleLen; $i++) { ?>
            addRule(<?php echo $aHuman[$i]; ?>, <?php echo $aHumanP[$i]; ?>)
        <?php } ?>

        <?php if ($aEarly != '') { ?>
            checkEarlyBird()
        <?php } ?>

        <?php if ($aUpper != '') { ?>
            getPeople()
            displayPeople()
        <?php } ?>

        <?php if ($fLoc != '') { ?>
            document.getElementById('actLoc').value = document.getElementById('farmLoc').innerText
        <?php } ?>

        /* add div tag func */
        function addDiv(getNode, getName) {
            getNode.setAttribute('class', getName)
            getNode.setAttribute('name', getName)
            getNode.setAttribute('id', getName)
        }

        /* add font tag fun */
        function addFont(getNode, getText = '') {
            var text = document.createTextNode(getText)
            getNode.appendChild(text)
        }

        /* add to form tag func */
        function addForm(getNode, getText, getElement) {
            addTwoBr(getNode)
            getNode.appendChild(getText)
            getNode.appendChild(getElement)
        }

        /* add two br tag func */
        function addTwoBr(getNode) {
            getNode.appendChild(document.createElement('br'))
            getNode.appendChild(document.createElement('br'))
        }

        /* add input tag func */
        function addInput(getNode = '', getType = '', getName = '', getValue = '', boolValue = false, boolRequire =
            false) {
            getNode.setAttribute('type', getType)
            getNode.setAttribute('name', getName)
            getNode.setAttribute('id', getName)

            if (boolValue)
                getNode.setAttribute('value', getValue)

            if (boolRequire)
                getNode.setAttribute('required', '')
        }

        /* get actPeople value to create range input func */
        function getPeople() {
            var actUpper = document.getElementById('actUpper')
            var actUpperDiv = document.getElementById('upperPeople')
            var number = parseInt(actUpper.value)

            /* add actPeople range input */
            if (document.getElementById('actLower')) {
                actUpperDiv.removeChild(actLowerInput)
                actUpperDiv.removeChild(actLowerText)
                actUpperDiv.removeChild(actLowerBr1)
                actUpperDiv.removeChild(actLowerBr2)
            }
            actLowerBr1 = document.createElement('br')
            actLowerBr2 = document.createElement('br')
            actUpperDiv.appendChild(actLowerBr1)
            actUpperDiv.appendChild(actLowerBr2)

            actLowerText = document.createElement('p')
            addFont(actLowerText, 'People Lower Bound')
            actUpperDiv.appendChild(actLowerText)

            actLowerInput = document.createElement('input')
            addInput(actLowerInput, 'range', 'actLower', '', false, true)
            actLowerInput.setAttribute('max', number - 1)
            actLowerInput.setAttribute('min', 1)
            actLowerInput.setAttribute('oninput', 'displayPeople()')
            <?php if ($aLower != '') { ?>
                actLowerInput.setAttribute('value', '<?php echo $aLower; ?>')
            <?php } ?>
            actUpperDiv.appendChild(actLowerInput)
        }

        function displayPeople() {
            var actPeople = document.getElementById('actLower')
            var number = parseInt(actPeople.value)
            actLowerText.innerHTML = 'People Lower Bound : ' + number
        }

        function addFarmData(getNodeH2, h2TagName = '', getNodeH3, h3TagName = '') {
            wrapFarmDiv.appendChild(document.createElement('br'))
            addFont(getNodeH2, h2TagName)
            wrapFarmDiv.appendChild(getNodeH2)
            addFont(getNodeH3, h3TagName)
            wrapFarmDiv.appendChild(getNodeH3)
        }

        function checkEarlyBird() {
            var earlyBird = document.getElementById('actEarlyInput').checked
            var actEarlyDiv = document.getElementById('actEarly');

            if (earlyBird) {
                actEarlyBirdBr = document.createElement('br')
                actEarlyBirdBr2 = document.createElement('br')
                actEarlyBirdSpan1 = document.createElement('span')
                addFont(actEarlyBirdSpan1, 'day ')
                actEarlyDateInput = document.createElement('input')
                <?php if ($aEarly != '') { ?>
                    addInput(actEarlyDateInput, 'date', 'actEarlyDate', '<?php echo subStr($aEarly, 0, 10); ?>', true, true)
                <?php } else { ?>
                    addInput(actEarlyDateInput, 'date', 'actEarlyDate', '', false, true)
                <?php } ?>
                actEarlyDateInput.setAttribute('max', '<?php echo $earlyDay; ?>')
                actEarlyDiv.appendChild(actEarlyBirdBr)
                actEarlyDiv.appendChild(actEarlyBirdBr2)
                actEarlyDiv.appendChild(actEarlyBirdSpan1)
                actEarlyDiv.appendChild(actEarlyDateInput)

                span = document.createElement('span')
                addFont(span, '  ')
                actEarlyBirdSpan2 = document.createElement('span')
                addFont(actEarlyBirdSpan2, 'price ')
                actEarlyPriceInput = document.createElement('input')
                <?php if ($aEarly != '') { ?>
                    addInput(actEarlyPriceInput, 'number', 'actEarlyPrice', '<?php echo $aEarlyP; ?>', true, true)
                <?php } else { ?>
                    addInput(actEarlyPriceInput, 'number', 'actEarlyPrice', '', false, true)
                <?php } ?>
                actEarlyDiv.appendChild(span)
                actEarlyDiv.appendChild(actEarlyBirdSpan2)
                actEarlyDiv.appendChild(actEarlyPriceInput)
            } else {
                actEarlyDiv.removeChild(actEarlyBirdBr)
                actEarlyDiv.removeChild(actEarlyBirdBr2)
                actEarlyDiv.removeChild(actEarlyBirdSpan1)
                actEarlyDiv.removeChild(actEarlyDateInput)
                actEarlyDiv.removeChild(span)
                actEarlyDiv.removeChild(actEarlyBirdSpan2)
                actEarlyDiv.removeChild(actEarlyPriceInput)
            }
        }

        function addRule(getHuman = '', getPrice = '') {
            var addPeopleRuleDiv = document.getElementById('peopleRule')

            newDiv = document.createElement('div')
            addDiv(newDiv, parseInt(ruleCount + 1))

            ruleCountSpan = document.createElement('span')
            addFont(ruleCountSpan, 'Rule' + parseInt(ruleCount + 1) + ' ')

            addHumanRuleSpan = document.createElement('span')
            addFont(addHumanRuleSpan, ' people ')

            addHumanRuleInput = document.createElement('input')
            addInput(addHumanRuleInput, 'number', 'humanRule[]', getHuman, true, true)

            addPriceRuleSpan = document.createElement('span')
            addFont(addPriceRuleSpan, ' price ')

            addPriceRuleInput = document.createElement('input')
            addInput(addPriceRuleInput, 'number', 'priceRule[]', getPrice, true, true)

            newDiv.appendChild(document.createElement('br'))
            newDiv.appendChild(document.createElement('br'))
            newDiv.appendChild(ruleCountSpan)
            newDiv.appendChild(addHumanRuleSpan)
            newDiv.appendChild(addHumanRuleInput)
            newDiv.appendChild(addPriceRuleSpan)
            newDiv.appendChild(addPriceRuleInput)

            addPeopleRuleDiv.appendChild(newDiv)
            ruleCount++
        }

        function reduceRule() {
            if (ruleCount > 0) {
                var addPeopleRuleDiv = document.getElementById('peopleRule')
                var delDiv = document.getElementById(parseInt(ruleCount));

                addPeopleRuleDiv.removeChild(delDiv)
                ruleCount--
            }
        }

        function checkJoinDay() {
            if (document.getElementById('publishStatus').checked) {
                document.getElementById('actAdvance').disabled = false;
            } else {
                document.getElementById('actAdvance').disabled = true;
            }
        }

        function ControlTime() {
            let beginTime = document.getElementById('actTimeBegin')
            let endTime = document.getElementById('actTimeEnd')

            if (beginTime.value > endTime.value) {
                endTime.value = beginTime.value;
                endTime.min = beginTime.value;
            }
        }

        function ckImage() {
            let img = document.getElementById('actImage').value.substr(document.getElementById('actImage').value.lastIndexOf(".")).toLowerCase(); //獲得檔案字尾名
            if (img != '.jpg' && img != '.png') {
                alert("Please upload jpg or png!");
                document.getElementById('actImage').value = "";
            }
        }
    </script>
</body>

</html>