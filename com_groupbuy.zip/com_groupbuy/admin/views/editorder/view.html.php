<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * GroupBuys View
 *
 * @since  0.0.1
 */
class GroupBuyViewEditorder extends JViewLegacy
{
	/**
	 * Display the Group Buy view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	function display($tpl = null)
	{
		// Get data from the model
		$this->items		= $this->get('Items');
		$this->pagination	= $this->get('Pagination');

		$this->addToolbar();
		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			// Get a handle to the Joomla! application object
			$application = JFactory::getApplication();

			// Add a message to the message queue
			$application->enqueueMessage(JText::_($errors), 'error');

			/** Alternatively you may use chaining */
			JFactory::getApplication()->enqueueMessage(JText::_($errors), 'error');
			return false;
		}

		// Display the template
		parent::display($tpl);
	}

	protected function addToolbar()
	{
		// assuming you have other toolbar buttons ...

		JToolBarHelper::title('訂單管理頁面');
	}
}
