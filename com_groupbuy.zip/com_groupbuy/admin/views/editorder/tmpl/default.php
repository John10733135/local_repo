<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// Stop direct access of file 阻止直接存取文件
defined('_JEXEC') or die('Restricted access');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>management actOrder</title>
    <style>
        * {
            padding: 0;
            margin: 0;
            list-style: none;
        }

        .container {
            width: 100%;
            text-align: center;
            margin: 20px auto;
        }

        .container h1 {
            margin: 10px auto;
        }

        .container table {
            margin: auto;
        }

        .content-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 1em;
            border-radius: 5px 5px 0 0;
            overflow: hidden;
        }

        .content-table thead tr {
            background-color: teal;
            color: white;
            text-align: center;
            font-weight: bold;
        }

        .content-table th,
        .content-table td {
            padding: 12px 15px;
        }

        .content-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .content-table tbody tr:last-of-type {
            border-bottom: 2px solid teal;
        }

        select {
            box-sizing: border-box;
            width: 100%;
            margin: 0;
            padding: 5px;
        }

        .submitBtn {
            box-sizing: border-box;
            padding: 5px;
            border: 1px solid teal;
            background-color: white;
            color: teal;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Order management page</h1>
        <table class="content-table">
            <thead>
                <tr>
                    <th>name</th>
                    <th>phone</th>
                    <th>tel</th>
                    <th>e-mail</th>
                    <th>FB / Line</th>
                    <th>adult amount</th>
                    <th>child amount</th>
                    <th>order sum</th>
                    <th>bank account</th>
                    <th>time</th>
                    <th>status</th>
                    <th>update status</th>
                    <th>submit status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                for ($i = 0; $i < count($this->items); $i++) {
                    $value = $this->items[$i];
                    echo "<tr>";
                    echo '<form name="actForm" id="actForm" method="post" action="' .  JUri::getInstance() . '&task=editorder.edit' . '">';

                    echo "<td>";
                    echo $value->order_name;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_phone;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_tel;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_mail;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_memo;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_adult;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_child;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_amount;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_account;
                    echo "</td>";

                    echo "<td>";
                    echo $value->order_time;
                    echo "</td>";

                    echo "<td>";
                    switch ($value->order_status) {
                        case 0:
                            echo "not confirm";
                            break;
                        case 1:
                            echo "<font color='blue'>confirm</font>";
                            break;
                        case -1:
                            echo "<font color='red'>void</font>";
                            break;
                    }
                    echo "</td>";

                    echo "<td>";
                    echo '<select name="editStatus" id="editStatus">';
                    if ($value->order_status == 0)
                        echo '<option value="0" selected>not confirm</option>';
                    else
                        echo '<option value="0">not confirm</option>';

                    if ($value->order_status == 1)
                        echo '<option value="1" selected>confirm</option>';
                    else
                        echo '<option value="1">confirm</option>';

                    if ($value->order_status == -1)
                        echo '<option value="-1" selected>void</option>';
                    else
                        echo '<option value="-1">void</option>';
                    echo '</select>';
                    echo "</td>";

                    echo "<td>";
                    echo '<input type="hidden" name="editID" value="' . $value->order_id . '">';
                    echo '<input type="submit" class="submitBtn" value="edit">';
                    echo "</td>";
                    echo '</form>';
                    echo "</tr>";
                } ?>
            </tbody>
        </table>
    </div>
</body>

</html>