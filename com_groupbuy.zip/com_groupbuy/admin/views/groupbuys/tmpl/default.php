<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// Stop direct access of file 阻止直接存取文件
defined('_JEXEC') or die('Restricted access');
$session = JFactory::getSession();
$URL = JUri::base();
if ($this->items[0]->farm_name == '') { ?>
    <script>
        alert('請填寫農場資料')
        top.location = "<?php $URL; ?>index.php?option=com_groupbuy&view=addfarm"
    </script>
<?php
} else {
    switch ($this->items[sizeof($this->items) - 1]->act_id) {
        case NULL:
            $session->set('lastActName', 1);
            break;
        default:
            $currentNum = $this->items[sizeof($this->items) - 1]->act_id + 1;
            $session->set('lastActName', $currentNum);
            break;
    }
    /* 處理活動陣列 */
    for ($i = 1; $i <= 12; $i++) {
        $eventDate[$i] = [];
        $eventName[$i] = [];
        $eventID[$i] = [];
        $eventPublish[$i] = [];
    }
    if ($this->items[0]->act_id != null) {
        for ($i = 0; $i < sizeof($this->items); $i++) {
            $someDay = new DateTime($this->items[$i]->act_time_start);
            $eventDate[$someDay->format('n')][] = $someDay->format('Y-n-j');
            $eventName[$someDay->format('n')][] = $this->items[$i]->act_name;
            $eventID[$someDay->format('n')][] = $this->items[$i]->act_id;
            $eventPublish[$someDay->format('n')][] = $this->items[$i]->act_status;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>calendarLayout 4.0</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .wrap {
            height: 100%;
            margin: auto;
            width: 90%;
        }

        .calendar {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            grid-template-rows: repeat(6, 1fr);
            text-align: center;
            font-size: 100%;
            background-color: #F0F8FF;
            margin: auto auto 1% auto;
        }

        .calendarWeek {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            grid-template-rows: 1fr;
            text-align: center;
            font-size: 100%;
        }

        .calendar-title {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            grid-template-rows: 1fr;
            padding: 1%;
            text-align: center;
            margin: 1% auto 0.2% auto;
            font-weight: bold;
            font-size: 150%;
            background-color: #1E90FF;
            color: white;
            border-radius: 5px;
        }

        .calendar-title button {
            width: 20%;
            height: 100%;
            border: none;
            background-color: #1E90FF;
            font-weight: bold;
            font-size: 100%;
            color: white;
        }

        .week {
            margin: 0.2% 0.5%;
            padding: 1%;
            background-color: #5E86C1;
            color: white;
            font-weight: bold;
            border-radius: 5px;
        }

        .week:hover {
            transform: scale(1.05);
            transition: 0.5s;
        }

        .box {
            border-style: solid;
            border-width: 0.1%;
            margin: 0.5%;
            padding-top: 1%;
            height: 150px;
            border-radius: 5px;
        }

        .CurrentMonth {
            border-color: #00BFFF;
            background-color: white;
        }


        .CurrentMonth:hover {
            border-color: black;
            border-style: solid;
            border-width: 0.1%;
            transform: scale(1.05);
            transition: 0.25s;
        }

        .day-weekend {
            color: red;
        }

        .notCurrentMonth {
            border-color: #5E86C1;
        }

        .event {
            margin: 0.5% auto;
            width: 75%;
            color: white;
            font-weight: bold;
            font-size: 100%;
            border-style: solid;
            border-width: 1%;
            border-radius: 50px;
            box-sizing: border-box;
        }

        .today {
            border-color: #4D80E6;
            background-color: #4D80E6;
            margin: 1% auto;
        }

        .notDueEvent {
            border-color: #2ac093;
            background-color: #2ac093;
            margin: 1% auto;
        }

        .dueEvent {
            border-color: #DCDCDC;
            background-color: #DCDCDC;
            margin: 1% auto;
        }

        .isPublish {
            border: 3px dashed red;
        }

        .event:hover {
            width: 85%;
            transition: 0.5s;
            border-color: gray;
        }

        a {
            display: block;
            text-decoration: none;
            color: black;
        }
    </style>
</head>

<body>
    <div class="wrap">
        <div class="calendar-title" id="calendar-title"></div>
        <div class="calendarWeek" id="calendarWeek"></div>
        <div class="calendar" id="calendar"></div>
    </div>
    <script>
        var actUrl = "<?php $URL; ?>index.php?option=com_groupbuy&view=addact"

        // Use Javascript date object
        var dateObj = new Date() // get current system time
        queryDate = new Date(dateObj.getFullYear(), dateObj.getMonth(), 1) // get this month

        // all for fix time now
        const yearNow = dateObj.getFullYear()
        const monthNow = dateObj.getMonth()
        const dayNow = dateObj.getDate()

        // all for create div block
        const todayStr = '<div class="event today">today</div>'
        const divClassStart = "<div class="
        const divClassIdStart = "id="
        const divEnd = "</div>"
        const aStart = "<a target=\"_blank\" href="
        const aEnd = "</a>"

        // get html div block for insertHtml based
        const calendarTitle = document.getElementById("calendar-title")
        const calendarWeek = document.getElementById("calendarWeek")
        const calendar = document.getElementById("calendar")

        // create Week & Month array
        const monthName = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
            "October", "November", "December"
        ]
        const weekName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

        // create week
        for (let wk = 0; wk < weekName.length; wk++) {
            calendarWeek.insertAdjacentHTML("beforeend", '<div class = "week">' + weekName[wk] + '</div>')
        }

        initAll()

        function initAll() {
            calendarTitle.innerHTML = ""
            calendar.innerHTML = ""
            calendarWk = queryDate.getDay()
            countDay = 42
            innerTitle()
            innerLastMonth()
            innerCurrentMonth()
            innerNextMonth()
            updateEvent()
        }

        function initTime() {
            year = dateObj.getFullYear()
            month = dateObj.getMonth()
            day = dateObj.getDate()
            divName = year + "-" + parseInt(month + 1) + "-" + day
        }

        function lastMonth() {
            queryDate = new Date(queryDate.getFullYear(), queryDate.getMonth() - 1, 1)
            initAll()
        }

        function nextMonth() {
            queryDate = new Date(queryDate.getFullYear(), queryDate.getMonth() + 1, 1)
            initAll()
        }


        function innerTitle() {
            calendarTitle.insertAdjacentHTML("beforeend",
                '<span class="titleL"><button type="button" onclick="lastMonth()">«</button></span>')
            calendarTitle.insertAdjacentHTML("beforeend", '<span class="titleM"><span>' + queryDate.getFullYear() +
                '</span><span>   </span><span>' + monthName[queryDate.getMonth()] + '</span></span>')
            calendarTitle.insertAdjacentHTML("beforeend",
                '<span class="titleR"><button type="button" onclick="nextMonth()">»</button></span>')
        }

        function innerLastMonth() {
            for (let lastDay = (-calendarWk) + 1; lastDay <= 0; lastDay++) {
                countDay--
                dateObj = new Date(queryDate.getFullYear(), queryDate.getMonth(), lastDay)
                initTime()
                Weekend = aStart + actUrl + '&setDay=' + divName + '>' + divClassStart + '"notCurrentMonth day-weekend box">' + dateObj.getDate() + divClassStart + divName + ' ' + divClassIdStart + divName + ">" + divEnd + divEnd + aEnd
                notWeekend = aStart + actUrl + '&setDay=' + divName + '>' + divClassStart + '"notCurrentMonth box">' + dateObj.getDate() + divClassStart + divName + ' ' + divClassIdStart + divName + ">" + divEnd + divEnd + aEnd

                if (dateObj.getDay() == 0 || dateObj.getDay() == 6)
                    calendar.insertAdjacentHTML("beforeend", Weekend)
                else
                    calendar.insertAdjacentHTML("beforeend", notWeekend)

                if (year == yearNow && month == monthNow && day == dayNow)
                    document.getElementById(divName).innerHTML = todayStr
            }
        }

        function innerCurrentMonth() {
            days = new Date(queryDate.getFullYear(), queryDate.getMonth() + 1, 0).getDate()

            for (let currentDay = 1; currentDay <= days; currentDay++) {
                countDay--
                dateObj = new Date(queryDate.getFullYear(), queryDate.getMonth(), currentDay)
                initTime()
                Weekend = aStart + actUrl + '&setDay=' + divName + '>' + divClassStart + '"CurrentMonth day-weekend box">' + dateObj.getDate() + divClassStart + divName + ' ' + divClassIdStart + divName + ">" + divEnd + divEnd + aEnd
                notWeekend = aStart + actUrl + '&setDay=' + divName + '>' + divClassStart + '"CurrentMonth box">' + dateObj.getDate() + divClassStart + divName + ' ' + divClassIdStart + divName + ">" + divEnd + divEnd + aEnd

                if ((calendarWk + currentDay - 1) % 7 == 6 || (calendarWk + currentDay - 1) % 7 == 0)
                    calendar.insertAdjacentHTML("beforeend", Weekend)
                else
                    calendar.insertAdjacentHTML("beforeend", notWeekend)

                if (year == yearNow && month == monthNow && day == dayNow)
                    document.getElementById(divName).innerHTML = todayStr
            }
        }

        function innerNextMonth() {
            for (let nextDay = 1; nextDay <= countDay; nextDay++) {
                dateObj = new Date(queryDate.getFullYear(), queryDate.getMonth() + 1, nextDay)
                initTime()
                Weekend = aStart + actUrl + '&setDay=' + divName + '>' + divClassStart + '"notCurrentMonth day-weekend box">' + dateObj.getDate() + divClassStart + divName + ' ' + divClassIdStart + divName + ">" + divEnd + divEnd + aEnd
                notWeekend = aStart + actUrl + '&setDay=' + divName + '>' + divClassStart + '"notCurrentMonth box">' + dateObj.getDate() + divClassStart + divName + ' ' + divClassIdStart + divName + ">" + divEnd + divEnd + aEnd

                if (dateObj.getDay() == 0 || dateObj.getDay() == 6)
                    calendar.insertAdjacentHTML("beforeend", Weekend)
                else
                    calendar.insertAdjacentHTML("beforeend", notWeekend)

                if (year == yearNow && month == monthNow && day == dayNow)
                    document.getElementById(divName).innerHTML = todayStr
            }
        }

        function updateEvent() {
            var setDate = [<?php echo json_encode($eventDate); ?>]
            var setStr = [<?php echo json_encode($eventName); ?>]
            var setID = [<?php echo json_encode($eventID); ?>]
            var setPublish = [<?php echo json_encode($eventPublish); ?>]

            var currentM = queryDate.getMonth() + 1

            for (let i = -1; i < 2; i++) {
                var qMonth = (currentM + i) % 12
                switch (qMonth) {
                    case 0:
                        setActItem(12, setDate, setPublish, setID, setStr)
                        break;
                    default:
                        setActItem(qMonth, setDate, setPublish, setID, setStr)
                        break;
                }
            }
        }

        function setActItem(month, setDate, setPublish, setID, setStr) {
            var nowDay = new Date();
            for (let j = 0; j < setDate[0][month].length; j++) {
                if (document.getElementById(setDate[0][month][j])) {

                    actDay = new Date(setDate[0][month][j].replace('-', ','));

                    if (actDay >= nowDay) {
                        if (setPublish[0][month][j] == 1)
                            document.getElementById(setDate[0][month][j]).insertAdjacentHTML("beforeend", aStart + actUrl + '&actID=' + setID[0][month][j] + '&setDay=' + setDate[0][month][j] + '><div class="event notDueEvent isPublish">' + setStr[0][month][j] + '</div></a>')
                        else
                            document.getElementById(setDate[0][month][j]).insertAdjacentHTML("beforeend", aStart + actUrl + '&actID=' + setID[0][month][j] + '&setDay=' + setDate[0][month][j] + '><div class="event notDueEvent">' + setStr[0][month][j] + '</div></a>')
                    } else {
                        if (setPublish[0][month][j])
                            document.getElementById(setDate[0][month][j]).insertAdjacentHTML("beforeend", aStart + actUrl + '&actID=' + setID[0][month][j] + '&setDay=' + setDate[0][month][j] + '><div class="event dueEvent isPublish">' + setStr[0][month][j] + '</div></a>')
                        else
                            document.getElementById(setDate[0][month][j]).insertAdjacentHTML("beforeend", aStart + actUrl + '&actID=' + setID[0][month][j] + '&setDay=' + setDate[0][month][j] + '><div class="event dueEvent">' + setStr[0][month][j] + '</div></a>')
                    }
                }
            }
        }
    </script>
</body>

</html>