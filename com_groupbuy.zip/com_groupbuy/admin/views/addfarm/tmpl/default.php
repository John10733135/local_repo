<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// Stop direct access of file 阻止直接存取文件
defined('_JEXEC') or die('Restricted access');

$fName = '';
$fOwner = '';
$fLoc = '';
$fCode = '';
$fAcc = '';
$fTel = '';
$fPhone = '';

foreach ($this->items as $value) {
    if ($value->farm_name != '') {
        $fName = $value->farm_name;
        $fOwner = $value->farm_owner;
        $fLoc = $value->farm_loc;
        $fCode = $value->bank_code;
        $fAcc = $value->farm_account;
        $fTel = $value->farm_tel;
        $fPhone = $value->farm_phone;
    }
    $code[] = $value->bank_code;
    $name[] = $value->bank_name;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Farm Data</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: "Microsoft JhengHei";
        }

        .wrap {
            margin: 0 auto 1% auto;
            width: 80%;
            text-align: center;
            border: 3px #1E90FF dashed;
            padding: 2%;
        }

        .title {
            width: 84.5%;
            padding-top: 2%;
            text-align: center;
            margin: 1% auto 1% auto;
            font-weight: bold;
            font-size: 32px;
            background-color: #1E90FF;
            color: white;
            border-radius: 5px;
        }

        .farmData #bankCode {
            width: 40%;
            height: 100%;
            padding: 1%;
            margin: auto 1%;
            font-size: 100%;
            text-align: center;
        }

        .farmData #farmAcc {
            width: 45%;
            margin: auto 1%;
            text-align: center;
        }

        .farmData {
            width: 85%;
            margin: auto;
            padding: 2%;
        }

        .farmData input {
            width: 95%;
            padding: 1%;
            font-size: 100%;
            text-align: center;
        }

        h2 {
            text-align: left;
            margin: auto;
            width: 85%;
        }

        p {
            text-align: left;
            font-weight: bold;
            margin-left: 5%;
            margin-top: 1%;
        }

        .submitBtn {
            margin: auto;
        }

        .submitBtn #btn {
            width: 20%;
            font-size: 125%;
            font-weight: bold;
            color: white;
            background-color: #5E86C1;
            border-style: double;
            border-radius: 25px;
            padding: 0.5%;

        }
    </style>
</head>

<body>
    <div class="title">
        <h1>填寫農場資料</h1><br>
    </div>
    <div class="wrap">
        <form action="<?php echo JUri::getInstance() . '&task=addfarm.save'; ?>" id="farmForm" name="farmForm" method="post">
            <h2>請輸入農場名稱</h2>
            <div class="farmData">
                <input type="text" id="farmName" name="farmName" value="<?php echo $fName; ?>" required>
            </div>
            <br><br>
            <h2>請輸入負責人</h2>
            <div class="farmData">
                <input type="text" id="farmOwner" name="farmOwner" value="<?php echo $fOwner; ?>" required>
            </div>
            <br><br>
            <h2>請輸入聯絡電話</h2>
            <div class="farmData">
                <p>行動電話</p>
                <input type="text" id="farmTel" name="farmTel" value="<?php echo $fTel; ?>" required>
                <p>室內電話</p>
                <input type="text" id="farmPhone" name="farmPhone" value="<?php echo $fPhone; ?>" required>
            </div>
            <br><br>
            <h2>請輸入通訊地址</h2>
            <div class="farmData">
                <input type="text" id="farmLoc" name="farmLoc" value="<?php echo $fLoc; ?>" required>
            </div>
            <br><br>
            <h2>請選擇銀行代碼與輸入銀行帳號</h2>
            <div class="farmData">
                <select name="bankCode" id="bankCode" required>
                    <option value=""></option>
                    <?php
                    for ($i = 0; $i < sizeof($code); $i++) {
                        if ($code[$i] == $fCode)
                            echo '<option value=' . $code[$i] . "' selected>";
                        else
                            echo '<option value=' . $code[$i] . "'>";
                        echo $code[$i] . ' - ' . $name[$i];
                        echo '</option>';
                    }
                    ?>
                </select>
                &nbsp&nbsp—&nbsp&nbsp
                <input type="text" id="farmAcc" name="farmAcc" value="<?php echo $fAcc; ?>" required>
            </div>
            <br><br>
            <div class="submitBtn">
                <input type="submit" id="btn" name="btn" value="確 認">
            </div>
        </form>
    </div>
</body>

</html>