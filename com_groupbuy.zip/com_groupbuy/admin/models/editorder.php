<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
class GroupBuyModelEditorder extends JModelList
{
	protected function getListQuery()
	{
		// Initialize variables.
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);

		$input = JFactory::getApplication()->input;

		$id = $input->get('actID');

		// Create the base select statement.

		$query->select(array('o.*'))
			->from($db->quoteName('#__groupbuy_order', 'o'))
			->where($db->quoteName('act_id') . '=' . $db->quote($id))
			->order('order_Status DESC');

		$this->setState('list.limit', 0);

		return $query;
	}

	public function edit($data)
	{
		$db = JFactory::getDbo();

		$statusQuery = $db->getQuery(true);

		$statusFields = array(
			$db->quoteName('order_status') . ' = ' . $db->quote($data['editStatus'])
		);

		$conditions = array($db->quoteName('order_id') . '=' . $db->quote($data['editID']));

		$statusQuery->update($db->quoteName('#__groupbuy_order'))->set($statusFields)->where($conditions);
		$db->setQuery($statusQuery);
		$db->execute();
	}
}
