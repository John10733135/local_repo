<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
class GroupBuyModelAddfarm extends JModelList
{
	protected function getListQuery()
	{
		// Initialize variables.
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);

		// Create the base select statement.

		$query->select(array('b.*', 'f.*'))
			->from($db->quoteName('#__farm_bank', 'b'))
			->join('LEFT', $db->quoteName('#__groupbuy_farm', 'f') . ' ON ' . $db->quoteName('f.farm_bank_code') . ' = ' . $db->quoteName('b.bank_code'));

		$this->setState('list.limit', 0);

		return $query;
	}

	public function save($data)
	{

		$db = JFactory::getDbo();

		$query = $db->getQuery(true);

		$fields = array(
			$db->quoteName('farm_name') . ' = ' . $db->quote($data['farmName']),
			$db->quoteName('farm_owner') . ' = ' . $db->quote($data['farmOwner']),
			$db->quoteName('farm_tel') . ' = ' . $db->quote($data['farmTel']),
			$db->quoteName('farm_phone') . ' = ' . $db->quote($data['farmPhone']),
			$db->quoteName('farm_loc') . ' = ' . $db->quote($data['farmLoc']),
			$db->quoteName('farm_bank_code') . ' = ' . $db->quote($data['accountCode']),
			$db->quoteName('farm_account') . ' = ' . $db->quote($data['farmAcc'])
		);

		$conditions = array(
			$db->quoteName('farm_id') . ' = 1'
		);

		$query->update($db->quoteName('#__groupbuy_farm'))->set($fields)->where($conditions);

		$db->setQuery($query);

		return $db->execute();
	}
}
