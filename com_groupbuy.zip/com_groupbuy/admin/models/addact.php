<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
class GroupBuyModelAddact extends JModelList
{
	protected function getListQuery()
	{
		// Initialize variables.
		$db    = JFactory::getDbo();
		$query = $db->getQuery(true);

		$input = JFactory::getApplication()->input;

		$id = $input->get('actID');

		if (!$id) {
			$query->select(array('c.*'))
				->from($db->quoteName('checkData', 'c'));

			$this->setState('list.limit', 0);

			return $query;
		}

		// Create the base select statement.

		$query->select(array('a.*'))
			->from($db->quoteName('checkActData', 'a'))
			->where($db->quoteName('act_id') . '=' . $db->quote($id));

		$this->setState('list.limit', 0);

		return $query;
	}

	public function save($data)
	{

		$db = JFactory::getDbo();

		$actQuery = $db->getQuery(true);
		$birdQuery = $db->getQuery(true);

		// Insert columns.
		$actColumns = array('act_id', 'act_name', 'act_intro', 'act_content', 'act_time_start', 'act_time_end', 'act_loc', 'act_lower', 'act_upper', 'act_price', 'act_status', 'act_advance', 'act_image', 'farm_id');

		// Insert values.
		$actValues = array(
			$db->quote($data['saveNextActID']), $db->quote($data['actName']), $db->quote($data['actIntro']), $db->quote($data['actContent']), $db->quote($data['saveDate'] . ' ' . $data['actTimeBegin'] . ':00'), $db->quote($data['saveDate'] . ' ' . $data['actTimeEnd'] . ':00'), $db->quote($data['actLoc']), $db->quote($data['actLower']), $db->quote($data['actUpper']), $db->quote($data['actPrice']), $db->quote($data['publishStatus']), $db->quote($data['actAdvance']), $db->quote($data['actImage']), $db->quote($data['saveFarmID'])
		);

		// Prepare the insert query.
		$actQuery
			->insert($db->quoteName('#__groupbuy_act'))
			->columns($db->quoteName($actColumns))
			->values(implode(',', $actValues));
		$db->setQuery($actQuery);
		$db->execute();


		$ruleColumns = array('act_id', 'act_human_rule', 'act_sale_type', 'act_early_rule', 'act_discount');

		if ($data['actEarlyInput'] == '1') {
			$ruleBirdValues = array($db->quote($data['saveNextActID']), '0', 1, $db->quote($data['actEarlyDate']), $db->quote($data['actEarlyPrice']));

			$birdQuery
				->insert($db->quoteName('#__groupbuy_act_rule'))
				->columns($db->quoteName($ruleColumns))
				->values(implode(',', $ruleBirdValues));
			$db->setQuery($birdQuery);
			$db->execute();
		}

		if ($data['humanRule'][0] != '') {
			for ($i = 0; $i < sizeof($data['humanRule']); $i++) {
				$humanQuery = $db->getQuery(true);
				$ruleHumanValues = array(
					$db->quote($data['saveNextActID']),
					$db->quote($data['humanRule'][$i]),
					0,
					'0000-00-00',
					$db->quote($data['priceRule'][$i])
				);

				$humanQuery
					->insert($db->quoteName('#__groupbuy_act_rule'))
					->columns($db->quoteName($ruleColumns))
					->values(implode(',', $ruleHumanValues));

				$db->setQuery($humanQuery);
				$db->execute();
			}
		}
	}

	public function edit($data)
	{
		$db = JFactory::getDbo();

		$actQuery = $db->getQuery(true);
		$deleteQuery = $db->getQuery(true);
		$birdQuery = $db->getQuery(true);

		$actFields = array(
			$db->quoteName('act_name') . ' = ' . $db->quote($data['actName']),
			$db->quoteName('act_intro') . ' = ' . $db->quote($data['actIntro']),
			$db->quoteName('act_content') . ' = ' . $db->quote($data['actContent']),
			$db->quoteName('act_time_start') . ' = ' . $db->quote($data['saveDate'] . ' ' . $data['actTimeBegin']),
			$db->quoteName('act_time_end') . ' = ' . $db->quote($data['saveDate'] . ' ' . $data['actTimeEnd']),
			$db->quoteName('act_loc') . ' = ' . $db->quote($data['actLoc']),
			$db->quoteName('act_lower') . ' = ' . $db->quote($data['actLower']),
			$db->quoteName('act_upper') . ' = ' . $db->quote($data['actUpper']),
			$db->quoteName('act_price') . ' = ' . $db->quote($data['actPrice']),
			$db->quoteName('act_image') . ' = ' . $db->quote($data['actImage'])
		);

		if (isset($data['publishStatus'])) {
			$actFields[] = $db->quoteName('act_status') . ' = ' . $db->quote($data['publishStatus']);
			$actFields[] = $db->quoteName('act_advance') . ' = ' . $db->quote($data['actAdvance']);
		} else {
			$actFields[] = $db->quoteName('act_status') . ' = ' . $db->quote($data['publishStatus']);
			$actFields[] = $db->quoteName('act_advance') . ' = ' . $db->quote($data['actAdvance']);
		}

		$conditions = array($db->quoteName('act_id') . '=' . $db->quote($data['actID']));

		$actQuery->update($db->quoteName('#__groupbuy_act'))->set($actFields)->where($conditions);

		$db->setQuery($actQuery);
		$db->execute();

		$deleteQuery->delete($db->quoteName('#__groupbuy_act_rule'))->where($conditions);
		$db->setQuery($deleteQuery);
		$db->execute();

		$ruleColumns = array('act_id', 'act_human_rule', 'act_sale_type', 'act_early_rule', 'act_discount');

		if ($data['actEarlyInput'] == '1') {
			$ruleBirdValues = array($db->quote($data['actID']), '0', 1, $db->quote($data['actEarlyDate']), $db->quote($data['actEarlyPrice']));

			$birdQuery
				->insert($db->quoteName('#__groupbuy_act_rule'))
				->columns($db->quoteName($ruleColumns))
				->values(implode(',', $ruleBirdValues));
			$db->setQuery($birdQuery);
			$db->execute();
		}

		if ($data['humanRule'][0] != '') {
			for ($i = 0; $i < sizeof($data['humanRule']); $i++) {
				$humanQuery = $db->getQuery(true);
				$ruleHumanValues = array(
					$db->quote($data['actID']),
					$db->quote($data['humanRule'][$i]),
					0,
					'0000-00-00',
					$db->quote($data['priceRule'][$i])
				);

				$humanQuery
					->insert($db->quoteName('#__groupbuy_act_rule'))
					->columns($db->quoteName($ruleColumns))
					->values(implode(',', $ruleHumanValues));

				$db->setQuery($humanQuery);
				$db->execute();
			}
		}
	}

	public function deleteAct($data)
	{
		$db = JFactory::getDbo();

		$delActQuery = $db->getQuery(true);
		$delRuleQuery = $db->getQuery(true);

		// delete all
		$conditions = array($db->quoteName('act_id') . '=' . $db->quote($data['actID']));

		$delActQuery->delete($db->quoteName('#__groupbuy_act'))->where($conditions);
		$db->setQuery($delActQuery);
		$db->execute();

		if ($data['ruleCount'] > 0) {
			$delRuleQuery->delete($db->quoteName('#__groupbuy_act_rule'))->where($conditions);
			$db->setQuery($delRuleQuery);
			$db->execute();
		}
	}
}
