<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * General Controller of GroupBuy component
 *
 * @package     Joomla.Administrator
 * @subpackage  com_groupbuy
 * @since       0.0.7
 */
class GroupBuyController extends JControllerLegacy
{
	/**
	 * The default view for the display method.
	 *
	 * @var string
	 * @since 12.2
	 */
	protected $default_view = 'groupbuys';
}
