<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * GroupBuy Controller
 *
 * @since  0.0.1
 */
class GroupBuyControllerAddact extends JControllerLegacy
{
    /**
     * Proxy for getModel.
     *
     * @param   string  $name    The model name. Optional.
     * @param   string  $prefix  The class prefix. Optional.
     * @param   array   $config  Configuration array for model. Optional.
     *
     * @return  object  The model.
     *
     * @since   1.6
     */

    protected $default_view = 'addact';

    public function save()
    {
        // 只取得 POST 的資料
        $post = $this->input->post;

        // 將 POST 資料塞進一個陣列中，用 getString() 避免不合法字元
        $data['saveDate'] = $post->getString('saveDate');
        $data['saveFarmID'] = $post->getString('saveFarmID');
        $data['saveNextActID'] = $post->getString('saveNextActID');
        $data['actName'] = $post->getString('actName');
        $data['actIntro'] = $post->getRaw('actIntro');
        $data['actContent'] = $post->getRaw('actContent');
        $data['actTimeBegin'] = $post->getString('actTimeBegin');
        $data['actTimeEnd'] = $post->getString('actTimeEnd');
        $data['actLoc'] = $post->getString('actLoc');
        $data['actPrice'] = $post->getString('actPrice');
        $data['actUpper'] = $post->getString('actUpper');
        $data['actLower'] = $post->getString('actLower');
        $data['actEarlyInput'] = $post->getInt('actEarlyInput');
        $data['actEarlyDate'] = $post->getString('actEarlyDate');
        $data['actEarlyPrice'] = $post->getString('actEarlyPrice');
        $data['actImage'] = "images" . explode('"', strip_tags(strstr($post->getRaw('actImage'), '/')))[0];

        if ($post->getString('publishStatus') == "1") {
            $data['publishStatus'] = 1;
            $data['actAdvance'] = $post->getString('actAdvance');
        } else {
            $data['publishStatus'] = 0;
            $data['actAdvance'] = "";
        }

        for ($i = 0; $i < sizeof($post->get('humanRule')); $i++) {
            $data['humanRule'][] = $post->getString('humanRule')[$i];
            $data['priceRule'][] = $post->getString('priceRule')[$i];
        }

        // 執行 save()
        $model = $this->getModel('addact');

        $model->save($data);

        // save() 完成後我們跳回 Article List 頁面
        $this->setRedirect(JRoute::_('index.php?option=com_groupbuy'));
    }

    public function edit()
    {
        $post = $this->input->post;

        $data['actID'] = $this->input->get('actID');
        $data['saveDate'] = $post->getString('saveDate');
        $data['actName'] = $post->getString('actName');
        $data['actIntro'] = $post->getRaw('actIntro');
        $data['actContent'] = $post->getRaw('actContent');
        $data['actTimeBegin'] = $post->getString('actTimeBegin');
        $data['actTimeEnd'] = $post->getString('actTimeEnd');
        $data['actLoc'] = $post->getString('actLoc');
        $data['actPrice'] = $post->getString('actPrice');
        $data['actUpper'] = $post->getString('actUpper');
        $data['actLower'] = $post->getString('actLower');
        $data['actEarlyInput'] = $post->getInt('actEarlyInput');
        $data['actEarlyDate'] = $post->getString('actEarlyDate');
        $data['actEarlyPrice'] = $post->getString('actEarlyPrice');
        $data['actImage'] = "images" . explode('"', strip_tags(strstr($post->getRaw('actImage'), '/')))[0];

        if ($post->getString('publishStatus') == "1") {
            $data['publishStatus'] = 1;
            $data['actAdvance'] = $post->getString('actAdvance');
        } else {
            $data['publishStatus'] = 0;
            $data['actAdvance'] = "";
        }

        for ($i = 0; $i < sizeof($post->get('humanRule')); $i++) {
            $data['humanRule'][] = $post->getString('humanRule')[$i];
            $data['priceRule'][] = $post->getString('priceRule')[$i];
        }

        $model = $this->getModel('addact');

        $model->edit($data);

        $this->setRedirect(JRoute::_('index.php?option=com_groupbuy'));
    }

    public function deleteAct()
    {
        $data['actID'] = $this->input->get('actID');
        $data['ruleCount'] = $this->input->get('ruleCount');
        $model = $this->getModel('addact');

        $model->deleteAct($data);

        $this->setRedirect(JRoute::_('index.php?option=com_groupbuy'));
    }
}
