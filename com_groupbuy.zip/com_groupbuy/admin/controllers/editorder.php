<?php

/**
 * @package Component groupbuy for Joomla! 3.3
 * @subpackage  com_groupbuy
 * @author John Guo
 * @copyright (C) 2010- John Guo
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * GroupBuy Controller
 *
 * @since  0.0.1
 */
class GroupBuyControllerEditorder extends JControllerLegacy
{
    /**
     * Proxy for getModel.
     *
     * @param   string  $name    The model name. Optional.
     * @param   string  $prefix  The class prefix. Optional.
     * @param   array   $config  Configuration array for model. Optional.
     *
     * @return  object  The model.
     *
     * @since   1.6
     */

    protected $default_view = 'editorder';

    public function edit()
    {
        // 只取得 POST 的資料
        $post = $this->input->post;

        // 將 POST 資料塞進一個陣列中，用 getString() 避免不合法字元
        $data['editID'] = $post->getString('editID');
        $data['editStatus'] = $post->getString('editStatus');

        // 執行 edit()
        $model = $this->getModel('editorder');

        $model->edit($data);

        // edit() 完成後我們跳回 Article List 頁面
        $this->setRedirect(JRoute::_('index.php?option=com_groupbuy'));
    }
}
