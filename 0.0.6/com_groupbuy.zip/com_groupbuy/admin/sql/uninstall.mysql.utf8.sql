DROP  TABLE  IF  EXISTS  `#__groupbuy_act`;
DROP  TABLE  IF  EXISTS  `#__groupbuymember`;