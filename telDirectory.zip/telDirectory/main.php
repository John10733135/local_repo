<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="main.js"></script>
    <title>10733135_telDirectory</title>
</head>
<?php
session_start();
if (isset($_SESSION['filedName']))
    unset($_SESSION['filedName']);

$conn = mysqli_connect('localhost', 'root', '');
$dbname = "telbook";

mysqli_query($conn, "set names utf8");

if (!mysqli_select_db($conn, $dbname))
    die("無法開啟 $dbname 資料庫!<br>");
else
    echo "資料庫: $dbname 開啟成功!<br>";

if (isset($_POST['del'])) {
    $sql = "DELETE FROM `employees` WHERE `EmployeeID` = '" . $_POST['del'] . "'";
    $result = mysqli_query($conn, $sql);
}
?>
<div class="wrap">
    <h1>Telephone directory</h1>
    <div class="menu-wrap">
        <ul>
            <a href="change.php">
                <li>新增</li>
            </a>
            <div class="queryBtn">
                <li>查詢</li>
            </div>
        </ul>
    </div>
    <div class="query-wrap">
        <form action="" method="POST">
            <label for="employeeName">姓名 :</label>&nbsp;&nbsp;
            <?php
            if (isset($_POST['employeeName']))
                echo "<input type='text' name='employeeName' id='employeeName' value='" . $_POST['employeeName'] . "'>";
            else
                echo "<input type='text' name='employeeName' id='employeeName'>";
            ?>
            <button class="submit">送出</button>
        </form>
    </div>
    <div class="dir-wrap">
        <table class="dir-table">
            <?php
            if (isset($_POST['employeeName']) && !empty($_POST['employeeName']))
                $sql = "SELECT `EmployeeID`, `EmployeeName`, `Title`, `TitleOfCourtesy`, `Address`, `Notes`, `Salary` FROM `employees` WHERE `EmployeeName` LIKE '" . $_POST['employeeName'] . "%'";
            else
                $sql = "SELECT `EmployeeID`, `EmployeeName`, `Title`, `TitleOfCourtesy`, `Address`, `Notes`, `Salary` FROM `employees`";
            $result = mysqli_query($conn, $sql);

            /* 分頁 */
            $totalNum = mysqli_num_rows($result);
            $count = 10;
            if (isset($_GET['p'])) {
                $p = $_GET['p'];
                $offset = ($p - 1) * $count;
                mysqli_data_seek($result, $offset);
            } else {
                $p = 1;
                mysqli_data_seek($result, 0);
            }

            echo "<thead>";

            while ($rows_data = mysqli_fetch_field($result)) {
                echo "<th>";
                echo $rows_data->name;
                echo "</th>";
                $_SESSION['filedName'][] = $rows_data->name;
            }

            echo "<th>";
            echo "修改";
            echo "</th>";

            echo "<th>";
            echo "刪除";
            echo "</th>";

            echo "</thead>";

            echo "<tbody>";

            $temp = $count;
            while ($row = mysqli_fetch_assoc($result)) {
                if ($temp < 1) {
                    break;
                }
                echo "<tr>";
                for ($i = 0; $i < count($_SESSION['filedName']); $i++)
                    echo "<td>" . $row[$_SESSION['filedName'][$i]] . "</td>";
                echo "<td><a href='change.php?eid=" . $row[$_SESSION['filedName'][0]] . "' class='btn'>修改</a></td>";
                echo "<form action='' method='POST'>";
                echo "<input type='hidden' name='del' value='" . $row[$_SESSION['filedName'][0]] . "'>";
                echo "<td><button class='btn'>刪除</button></td>";
                echo "</form>";
                echo "</tr>";

                $temp--;
            }
            mysqli_free_result($result);

            echo "</tbody>";

            ?>
        </table>
    </div>
    <div class="page">
        <?php
        if (($p - 1) < 1) {
            echo "<a href='main.php?p=" . $p . "'>上一頁 |</a>";
        } else {
            echo "<a href='main.php?p=" . ($p - 1) . "'>上一頁 |</a>";
        }

        for ($page = 1; $page <= ceil($totalNum / $count); $page++) {
            echo "&nbsp";
            if ($p == $page) {
                echo "$page";
            } else {
                echo "<a href='main.php?p=$page'>$page</a>";
            }
            echo "&nbsp";
        }

        if (($p + 1) > ceil($totalNum / $count)) {
            echo "<a href='main.php?p=" . $p . "'>| 下一頁</a>";
        } else {
            echo "<a href='main.php?p=" . ($p + 1) . "'>| 下一頁</a>";
        }

        mysqli_close($conn);

        ?>
    </div>
</div>

<body>

</body>

</html>