<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>10733135_telDirectory_insert</title>
</head>

<body>
    <?php
    session_start();
    $conn = mysqli_connect('localhost', 'root', '');
    $dbname = "telbook";

    mysqli_query($conn, "set names utf8");

    if (!mysqli_select_db($conn, $dbname))
        die("無法開啟 $dbname 資料庫!<br>");
    else
        echo "資料庫: $dbname 開啟成功!<br>";

    if (isset($_POST['status'])) {
        switch ($_POST['status']) {
            case 0: // 新增
                $getData = initData();
                $sql = "INSERT INTO `employees` (`EmployeeID`, `EmployeeName`, `Title`, `TitleOfCourtesy`, `Address`, `Notes`, `Salary`,`HireDate`) VALUES ($getData)";
                $result = mysqli_query($conn, $sql);
                break;
            case 1: // 修改
                $getData = explode(",", initData());
                $sql = "UPDATE `employees` SET `EmployeeID` = $getData[0],`EmployeeName` = $getData[1], `Title`= $getData[2], `TitleOfCourtesy`= $getData[3], `Address`= $getData[4], `Notes`= $getData[5], `Salary`= $getData[6] WHERE `EmployeeID` = '" . $_GET['eid'] . "'";
                $result = mysqli_query($conn, $sql);
                break;
        }
        header("location:main.php");
    }

    function initData()
    {
        $sIndex = $_SESSION['filedName'][0];
        $insertStr = "'" . $_POST[$sIndex] . "'";
        for ($i = 1; $i < count($_SESSION['filedName']); $i++) {
            $sIndex = $_SESSION['filedName'][$i];
            $insertStr = "$insertStr,'" . $_POST[$sIndex] . "'";
        }
        date_default_timezone_set('Asia/Taipei');
        $hirDate = date("Y:m:d h:i:s", time());

        return "$insertStr,'" . $hirDate . "'";
    }
    ?>
    <div class="wrap">
        <?php
        if (isset($_GET['eid'])) {
            echo "<h1>Update Data</h1>";
            $sql = "SELECT `EmployeeID`, `EmployeeName`, `Title`, `TitleOfCourtesy`, `Address`, `Notes`, `Salary` FROM `employees` WHERE `EmployeeID` = '" . $_GET['eid'] . "'";
            $result = mysqli_query($conn, $sql);
        } else
            echo "<h1>Insert Data</h1>";
        ?>


        <div class="menu-wrap">
            <ul>
                <a href="main.php">
                    <li>回通訊錄</li>
                </a>
            </ul>
        </div>
        <form action="" method="POST">
            <table class="dir-table">
                <?php
                echo "<thead>";

                for ($i = 0; $i < count($_SESSION['filedName']); $i++)
                    echo "<th>" . $_SESSION['filedName'][$i] . "</th>";

                echo "</thead>";

                echo "<tbody>";

                if (isset($_GET['eid'])) {
                    echo "<input type='hidden' name='status' value='1'>";

                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";

                        for ($i = 0; $i < count($_SESSION['filedName']); $i++) {
                            if ($i == 0)
                                echo "<td><input type='number' name='" . $_SESSION['filedName'][$i] . "' id='" . $_SESSION['filedName'][$i] . "' value='" . $row[$_SESSION['filedName'][$i]] . "' readonly required></td>";
                            else
                                echo "<td><input type='text' name='" . $_SESSION['filedName'][$i] . "' id='" . $_SESSION['filedName'][$i] . "' value='" . $row[$_SESSION['filedName'][$i]] . "'></td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    echo "<input type='hidden' name='status' value='0'>";

                    for ($i = 0; $i < count($_SESSION['filedName']); $i++) {
                        if ($i == 0)
                            echo "<td><input type='number' name='" . $_SESSION['filedName'][$i] . "' id='" . $_SESSION['filedName'][$i] . "' min = 0 required></td>";
                        else
                            echo "<td><input type='text' name='" . $_SESSION['filedName'][$i] . "' id='" . $_SESSION['filedName'][$i] . "'></td>";
                    }
                }
                echo "</tbody>";
                ?>
            </table>
            <?php
            if (isset($_GET['eid']))
                echo "<button class='submit'>修改</button>";
            else
                echo "<button class='submit'>新增</button>";
            ?>
        </form>
    </div>
</body>

</html>