$(document).ready(function() {

    // jQuery methods go here...
    $(".query-wrap").hide();
    $(".queryBtn").click(function() {
        $(".query-wrap").toggle();
    });

});